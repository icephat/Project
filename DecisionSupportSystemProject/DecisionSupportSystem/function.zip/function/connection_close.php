<?php 
    $conn->close();
?>